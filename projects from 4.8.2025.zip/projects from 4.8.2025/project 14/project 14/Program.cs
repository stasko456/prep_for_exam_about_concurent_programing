﻿namespace project_14
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            //ex 1:
            Task task = Task.Run(() =>
            {
                for (int i = 1; i <= 10; i++)
                {
                    Console.WriteLine(i);
                    Thread.Sleep(100);
                }
            });

            await task;
        }
    }
}

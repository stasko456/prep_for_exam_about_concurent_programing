﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_11
{
    public class BankAccount
    {
		private double balance;
		private string iban;
		private object _lock;

		public object Lock
		{
			get { return _lock; }
			set { _lock = value; }
		}

		public string IBAN
		{
			get { return this.iban; }
			set { this.iban = value; }
		}

		public double Balance
		{
			get { return this.balance; }
			set { this.balance = value; }
		}

		public void Withdraw(double amount)
		{
			lock (_lock)
			{
                Thread.Sleep(2000);
                this.Balance = this.Balance - amount;
                Console.WriteLine($"Withdrawed {amount} leva");
			}
		}

		public void Deposit(double amount)
		{
            lock (_lock)
            {
				Thread.Sleep(2000);
                this.Balance = this.Balance + amount;
                Console.WriteLine($"Deposited {amount} leva");
            }
        }

        public BankAccount(double balance, string iban)
        {
            this.Balance = balance;
			this.IBAN = iban;
			this.Lock = new object();
        }
    }
}

﻿using System.Threading;

namespace project_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount bankAccount = new BankAccount(1000.00, "BG26872513");
            Thread withdraw = new Thread(() => bankAccount.Withdraw(100));
            Thread deposit = new Thread(() => bankAccount.Deposit(200));
            withdraw.Start();
            deposit.Start();
        }
    }
}

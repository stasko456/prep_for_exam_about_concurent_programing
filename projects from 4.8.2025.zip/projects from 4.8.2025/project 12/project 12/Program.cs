﻿namespace project_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SmartLock smartLock = new SmartLock();
            Bathroom toilet = new Bathroom(smartLock, "bgf663");
            Person person1 = new Person();
            Person person2 = new Person();
            Thread thread1 = new Thread(() => person1.GoToilet(toilet));
            Thread thread2 = new Thread(() => person1.LeaveToilet(toilet));
            thread1.Start();
            thread2.Start();
        }
    }
}

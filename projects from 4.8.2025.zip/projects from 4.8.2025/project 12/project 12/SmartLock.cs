﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_12
{
    public class SmartLock
    {
		private bool isLocked;

		public bool IsLocked
		{
			get { return this.isLocked; }
			set { this.isLocked = value; }
		}

		public bool Open()
		{
			return !this.isLocked;
		}

		public void Lock()
		{
			this.IsLocked = true;
		}

		public void Unlock()
        {
            this.IsLocked = false;
        }

        public SmartLock()
        {
            this.IsLocked = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_12
{
    public class Bathroom
    {
		private SmartLock smartLock;
		private string id;

		public string Id
		{
			get { return this.id; }
			set { this.id = value; }
		}

		public SmartLock SmartLock
		{
			get { return smartLock; }
			set { smartLock = value; }
		}

        public Bathroom(SmartLock smartLock, string id)
        {
            this.SmartLock = smartLock;
			this.Id = id;
        }

		public bool Entry()
		{
            lock (this.SmartLock)
            {
                this.SmartLock.Lock();
                Thread.Sleep(2000);
                Console.WriteLine($"Someone used the toilet with id {this.Id}!");
                this.Leave();
            }
            return SmartLock.Open();
        }

        public void Leave()
        {
            this.SmartLock.Unlock();
            Console.WriteLine($"Someone left the toilet with id {this.Id}!");
        }

        public bool IsBusy()
        {
			return !this.SmartLock.Open();
        }
    }
}

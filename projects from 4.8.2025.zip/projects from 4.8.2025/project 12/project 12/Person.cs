﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_12
{
    public class Person
    {
		private string name;
		private int age;

		public int Age
		{
			get { return this.age; }
			set { this.age = value; }
		}

		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public void GoToilet(Bathroom toilet)
		{
			toilet.Entry();
		}

        public void LeaveToilet(Bathroom toilet)
        {
			toilet.Leave();
        }
    }
}

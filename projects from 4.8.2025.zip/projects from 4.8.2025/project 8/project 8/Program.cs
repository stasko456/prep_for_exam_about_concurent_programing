﻿//ex 1;
//Random random = new Random();
//void CountBackwards()
//{
//    int waitTime = random.Next(1,11) * 1000;
//    for (int i = 10; i >= 0; i--)
//    {
//        Console.WriteLine(i);
//        Thread.Sleep(waitTime);
//    }
//}
//Thread thread1 = new Thread(CountBackwards);
//Thread thread2 = new Thread(CountBackwards);
//thread1.Start(); thread2.Start();

//ex 2:
//Random random = new Random();
//void Player1()
//{
//    int points = 0;
//    int endPoints = 100;
//    while (points < endPoints)
//    {
//        points = points + random.Next(1,11);
//        Console.WriteLine($"Player1 points: {points}");
//        Thread.Sleep(1000);
//    }
//    Console.WriteLine("Player1 finished!");
//}
//void Player2()
//{
//    int points = 0;
//    int endPoints = 100;
//    while (points < endPoints)
//    {
//        points = points + random.Next(1, 11);
//        Console.WriteLine($"Player2 points: {points}");
//        Thread.Sleep(1000);
//    }
//    Console.WriteLine("Player2 finished!");
//}
//Thread thread1 = new Thread(Player1);
//Thread thread2 = new Thread(Player2);
//thread1.Start(); thread2.Start();

//ex 3:
//Thread thread = new Thread(MyMethod);
//ThreadPool.QueueUserWorkItem(new WaitCallback(MyMethod), "thread pool");
//thread.Start("plain thread");
//MyMethod("main");
//static void MyMethod(object obj)
//{
//    Thread thread = Thread.CurrentThread;
//    string message = $"Background {thread.IsBackground}, Thread Pool:{thread.IsThreadPoolThread}, Thread ID:{thread.ManagedThreadId}{obj}.";
//    Console.WriteLine(message);
//}

//ex 4:
using System;
using System.Threading;
//for (int i = 0; i < 10; i++)
//{
//    ThreadPool.QueueUserWorkItem(RandomNumberGenerator);
//}

//static void RandomNumberGenerator(object state)
//{
//    Thread thread = Thread.CurrentThread;
//    Random random = new Random();
//    int randomNumber = random.Next(1, 101);
//    Console.WriteLine($"Value: {randomNumber}, ThreadID:{thread.ManagedThreadId}");
//}



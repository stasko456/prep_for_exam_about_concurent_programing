﻿using System;
using System.Threading;

namespace project_10
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ThreadPool.QueueUserWorkItem(Print1, "bla");
            ThreadPool.QueueUserWorkItem(Print2, "bla");
            ThreadPool.QueueUserWorkItem(Print3, "bla");
        }

        public static void Print1(object state)
        {
            Console.WriteLine("kvo");
        }

        public static void Print2(object state)
        {
            Console.WriteLine("staa");
        }

        public static void Print3(object state)
        {
            Console.WriteLine("maina");
        }
    }
}

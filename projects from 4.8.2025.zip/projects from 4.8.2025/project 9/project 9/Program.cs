﻿namespace project_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Thread thread1 = new Thread(Player1);
            Thread thread2 = new Thread(Player2);
            thread1.Start();
            thread2.Start();
        }

        static Random random = new Random();

        //public static void CountBackwards()
        //{
        //    int waitTime = random.Next(1, 10) * 1000;
        //    Console.WriteLine($"Wait time: {waitTime}");
        //    for (int i = 10; i >= 0; i--)
        //    {
        //        Console.WriteLine(i);
        //        System.Threading.Thread.Sleep(waitTime);
        //    }
        //}

        public static void Player1()
        {
            int endPoints = 100;
            int currentPoints = 0;
            while (currentPoints <= endPoints)
            {
                currentPoints = currentPoints + random.Next(1, 10);
                Console.WriteLine($"Player1's current points: {currentPoints}");
                System.Threading.Thread.Sleep(1000);
            }
            Console.WriteLine("Player1 FINISHED!");
        }

        public static void Player2()
        {
            int endPoints = 100;
            int currentPoints = 0;
            while (currentPoints <= endPoints)
            {
                currentPoints = currentPoints + random.Next(1, 10);
                Console.WriteLine($"Player2's current points: {currentPoints}");
                System.Threading.Thread.Sleep(1000);
            }
            Console.WriteLine("Player2 FINISHED!");
        }
    }
}

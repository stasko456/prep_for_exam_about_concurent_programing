﻿namespace project_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SmartLock smartLock = new SmartLock();
            Bathroom bathroom = new Bathroom(smartLock, "bg6482");
            Person person1 = new Person("pesho", 45);
            Person person2 = new Person("Malin", 28);
            Thread thread1 = new Thread(() => person1.GoToToilet(bathroom));
            Thread thread2 = new Thread(() =>person2.LeaveToilet(bathroom));
            thread1.Start();
            thread2.Start();
        }
    }
}

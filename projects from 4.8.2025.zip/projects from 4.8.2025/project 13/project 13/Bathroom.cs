﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_13
{
    public class Bathroom
    {
		private SmartLock smartLock;
		private string id;

		public string Id
		{
			get { return this.id; }
			set { this.id = value; }
		}

		public SmartLock SmartLock
		{
			get { return this.smartLock; }
			set { this.smartLock = value; }
		}

        public Bathroom(SmartLock smartLock, string id)
        {
            this.SmartLock = smartLock;
			this.Id = id;
        }

		public bool Enter()
		{
			lock (this.SmartLock)
			{
				this.SmartLock.Lock();
				Thread.Sleep(2000);
                Console.WriteLine($"Someone used toilet {this.Id}");
                this.Leave();
            }
			return SmartLock.Open();
        }

		public void Leave()
		{
            this.SmartLock.Unlock();
            Console.WriteLine($"Someone left toilet {this.Id}");
		}

		public bool IsBusy()
		{
			return !SmartLock.Open();
		}
    }
}
